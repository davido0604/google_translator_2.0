package com.example.google_translate_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
