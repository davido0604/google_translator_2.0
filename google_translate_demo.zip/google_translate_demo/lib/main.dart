import 'package:flutter/material.dart';
import 'package:translator/translator.dart';

void main() {
  runApp(
     MaterialApp(
      home: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  MyApp({super.key});
  String translated = 'Translation';
  @override

  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      leading: const Icon(Icons.translate),
      title: const Text('Google Translate'),
    ),
    body: Card(
        margin: const EdgeInsets.all(12),
        child: ListView(
          padding: const EdgeInsets.all(12),
          children: [
            Text('English (US)'),
            SizedBox(height: 8),
            TextField(
              style: TextStyle(
                fontSize: 36,
                fontWeight: FontWeight.bold,
              ),
              decoration: InputDecoration(
                hintText: 'Enter Text',
              ),
              onChanged: (text) async {
                // final translator = GoogleTranslator();
                // final input = text;

                final translation = await text.translate(from: 'en', to: 'es',);
                // translator.translate(input, to: 'en').then((result) => translated = result as String);

                // kan ikke bruke setState, så får ikke kjørt appen
                //setState(() {
                  translated = translation.text;
                });
              },
            ),
            Divider(height: 32),
            Text(
              translated,
              style: TextStyle(
                fontSize: 36,
                color: Colors.lightBlueAccent,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        )
    ),
  );
}